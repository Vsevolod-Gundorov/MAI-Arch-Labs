python3 lab6/user_app/gen.py $1
./lab6/user_app/build/app