python3 lab6/post_app/gen.py $1 $2
./lab6/post_app/build/app