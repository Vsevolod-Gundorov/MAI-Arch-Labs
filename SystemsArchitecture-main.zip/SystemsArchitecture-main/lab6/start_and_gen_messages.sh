python3 lab6/message_app/gen.py $1 $2
./lab6/message_app/build/app