python3 lab2/gen.py $1
./lab2/build/app