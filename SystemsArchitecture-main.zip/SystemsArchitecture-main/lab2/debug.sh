cmake -S . -B build -D CMAKE_BUILD_TYPE=Debug
cd build
make
cd ..