export DB_HOST=postgres
export DB_PORT=5432
export DB_LOGIN=stud
export DB_PASSWORD=stud
export DB_DATABASE=archdb

./build/app