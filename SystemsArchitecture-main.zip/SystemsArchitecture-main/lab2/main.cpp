#include "user_server/user_server_application.h"

int main(int argc, char*argv[]){
    UserServerApplication app;
    return app.run(argc, argv);
}