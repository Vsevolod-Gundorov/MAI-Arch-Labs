python3 lab3/gen_posts.py $1 $2
./lab3/post_app/build/app