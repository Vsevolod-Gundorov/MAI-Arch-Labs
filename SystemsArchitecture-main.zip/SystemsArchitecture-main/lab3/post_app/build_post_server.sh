cmake -S . -B build --target post_app
cd build
make
cd ..