cmake -S . -B build --target message_app
cd build
make
cd ..