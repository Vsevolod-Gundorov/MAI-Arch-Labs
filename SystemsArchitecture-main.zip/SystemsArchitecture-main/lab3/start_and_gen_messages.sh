python3 lab3/gen_messages.py $1 $2
./lab3/message_app/build/app