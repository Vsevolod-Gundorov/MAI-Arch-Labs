export MONGO_HOST=mongodb
export MONGO_PORT=27017
export MONGO_DATABASE=arch

./build/app