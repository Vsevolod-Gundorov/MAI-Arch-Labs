cd message_app
./build.sh

cd ../post_app
./build.sh