python3 lab4/message_app/gen.py $1 $2
./lab4/message_app/build/app