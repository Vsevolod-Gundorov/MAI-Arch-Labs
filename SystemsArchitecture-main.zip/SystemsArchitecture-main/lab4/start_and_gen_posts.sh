python3 lab4/post_app/gen.py $1 $2
./lab4/post_app/build/app