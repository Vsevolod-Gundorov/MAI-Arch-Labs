python3 lab4/user_app/gen.py $1
./lab4/user_app/build/app