python3 lab5/post_app/gen.py $1 $2
./lab5/post_app/build/app