python3 lab5/message_app/gen.py $1 $2
./lab5/message_app/build/app