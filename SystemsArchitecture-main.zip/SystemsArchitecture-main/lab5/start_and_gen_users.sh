python3 lab5/user_app/gen.py $1
./lab5/user_app/build/app