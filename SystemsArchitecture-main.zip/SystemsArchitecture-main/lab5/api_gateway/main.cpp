#include "api_gateway_application.h"

int main(int argc, char*argv[]){
    APIGatewayApplication app;
    return app.run(argc, argv);
}